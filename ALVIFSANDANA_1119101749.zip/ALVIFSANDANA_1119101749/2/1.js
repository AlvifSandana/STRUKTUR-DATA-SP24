var beras = 260000;
var gula = 300000;
var minyak = 150000;
function InputQtyBarang(ID) {
    var input;
    var qty;
    input = document.getElementById(ID);
    qty = parseInt(input.value);
    return qty;
}
function HitungPembelian() {
    // Inisialisasi
    var pembelianBeras;
    var pembelianGula;
    var pembelianMinyak;
    var total;
    // Input
    pembelianBeras = beras * InputQtyBarang("qty1");
    pembelianGula = gula * InputQtyBarang("qty2");
    pembelianMinyak = minyak * InputQtyBarang("qty3");
    // Proses
    total = pembelianBeras + pembelianGula + pembelianMinyak;
    // Output
    document.getElementById("txtTotal").innerHTML = total.toString();
    return total;
}
function Cek() {
    // Inisialisasi
    var totalpembelian;
    var total;
    var diskon;
    var output;
    var souvenirout = "";
    // Input
    totalpembelian = HitungPembelian();
    // Proses
    if (totalpembelian < 340000) {
        diskon = 0;
        total = totalpembelian - diskon;
    }
    else if ((totalpembelian > 340000) && (totalpembelian < 1000000)) {
        diskon = totalpembelian * 5 / 100;
        total = totalpembelian - diskon;
    }
    else if ((totalpembelian >= 1000000) && (totalpembelian < 2000000)) {
        diskon = totalpembelian * 5 / 100;
        souvenirout = "Kaos";
        total = totalpembelian - diskon;
        //output = "Total Pembayaran yaitu: Rp" + total + "dengan souvenir: " + souvenirout;
    }
    else if ((totalpembelian >= 2000000) && (totalpembelian < 3000000)) {
        diskon = totalpembelian * 5 / 100;
        souvenirout = "Jam Tangan";
        total = totalpembelian - diskon;
        //output = "Total Pembayaran yaitu: Rp" + total + "dengan souvenir: " + souvenirout;
    }
    else if (totalpembelian >= 3000000) {
        diskon = totalpembelian * 5 / 100;
        souvenirout = "Tas";
        total = totalpembelian - diskon;
        //output = "Total Pembayaran yaitu: Rp" + total + "dengan souvenir: " + souvenirout;
    }
    else {
        alert("Mohon masukkan total pembelian Anda");
    }
    // Output
    output = "Total Pembayaran yaitu: Rp" + total + " dengan souvenir: " + souvenirout;
    Output("out", output);
}
function Output(ID, VAL) {
    var val = VAL;
    document.getElementById(ID).innerHTML = val;
}
