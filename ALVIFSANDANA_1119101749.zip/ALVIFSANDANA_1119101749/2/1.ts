const beras = 260000;
const gula = 300000;
const minyak = 150000;

function InputQtyBarang(ID: string){
    let input: HTMLInputElement;
    let qty: number;
    input = <HTMLInputElement>document.getElementById(ID);
    qty = parseInt(input.value);
    return qty;
}

function HitungPembelian(){
    // Inisialisasi
    let pembelianBeras: number;
    let pembelianGula: number;
    let pembelianMinyak: number;
    let total: number;
    // Input
    pembelianBeras = beras * InputQtyBarang("qty1");
    pembelianGula = gula * InputQtyBarang("qty2");
    pembelianMinyak = minyak * InputQtyBarang("qty3");
    // Proses
    total = pembelianBeras + pembelianGula + pembelianMinyak;
    // Output
    (<HTMLElement>document.getElementById("txtTotal")).innerHTML = total.toString();
    return total;
}

function Cek(){
    // Inisialisasi
    let totalpembelian: number;
    let total: number;
    let diskon: number;
    let output: string;
    var souvenirout: string = "";

    // Input
    totalpembelian = HitungPembelian();
    // Proses
    if (totalpembelian < 340000) {
        diskon = 0;
        total = totalpembelian - diskon;
    }else if ((totalpembelian > 340000) && (totalpembelian < 1000000)) {
        diskon = totalpembelian * 5 / 100;
        total = totalpembelian - diskon;
    }else if ((totalpembelian >= 1000000) && (totalpembelian < 2000000)) {
        diskon = totalpembelian * 5 / 100;
        souvenirout = "Kaos";
        total = totalpembelian - diskon;
        //output = "Total Pembayaran yaitu: Rp" + total + "dengan souvenir: " + souvenirout;
    }else if ((totalpembelian >= 2000000) && (totalpembelian < 3000000)) {
        diskon = totalpembelian * 5 / 100;
        souvenirout = "Jam Tangan";
        total = totalpembelian - diskon;
        //output = "Total Pembayaran yaitu: Rp" + total + "dengan souvenir: " + souvenirout;
    }else if (totalpembelian >= 3000000) {
        diskon = totalpembelian * 5 / 100;
        souvenirout = "Tas";
        total = totalpembelian - diskon;
        //output = "Total Pembayaran yaitu: Rp" + total + "dengan souvenir: " + souvenirout;
    }else{
        alert("Mohon masukkan total pembelian Anda");
    }
    // Output
    output = "Total Pembayaran yaitu: Rp" + total + " dengan souvenir: " + souvenirout; 
    Output("out", output);
}

function Output(ID: string, VAL: string){
    let val: string = VAL;
    (<HTMLElement>document.getElementById(ID)).innerHTML = val;
}